const DB_NAME = "ZIP-PROPERTIES";
let db;

function openDb() {
    return new Promise(openDatabase);
}

function openDatabase(resolve, reject) {
    if (!window.indexedDB) {
        console.log(`Your browser doesn't support IndexedDB`);
        return;
    }

    // open the CRM database with the version 1
    const request = indexedDB.open(DB_NAME, 1);

    // create the Contacts object store and indexes
    request.onupgradeneeded = (event) => {
        db = event.target.result;

        // create the Contacts object store 
        // with auto-increment id
        let store = db.createObjectStore('Properties', {
            autoIncrement: false
        });

        // create an index on the email property
        // let index = store.createIndex('email', 'email', {
        //     unique: true
        // });
    };

    // handle the error event
    request.onerror = (event) => {
        console.error(`Database error: ${event.target.errorCode}`);
        reject(event.target.errorCode);
    };

    // handle the success event
    request.onsuccess = (event) => {
        db = event.target.result;
        resolve();
    };
}

function insertProperties(zip, propsObj) {
    return new Promise(async (resolve, reject) => {
        
        let propsInDb = await getPropertiesByZipcode(zip);

        // create a new transaction
        const txn = db.transaction('Properties', 'readwrite');

        // get the Contacts object store
        const store = txn.objectStore('Properties');
        
        let query
        if(propsInDb === undefined)
        {
            //
            query = store.put(propsObj, zip);
            console.log("Put 1st", propsObj);
        } else {
            //propsObj.properties.push(...propsInDb.properties)
            propsObj.properties.unshift(...propsInDb.properties)
            query = store.put(propsObj, zip);
            console.log("Put next", propsObj);
        }
        

        // handle success case
        query.onsuccess = function (event) {
            console.log(event);
            resolve(propsObj);
        };

        // handle the error case
        query.onerror = function (event) {
            console.log(event.target.errorCode);
            reject(event.target.errorCode);
        }

        // close the database once the 
        // transaction completes
        txn.oncomplete = function () {
            //db.close();
        };
    });
}

function getPropertiesByZipcode(zipcode) {
    return new Promise((resolve, reject) => {

        const txn = db.transaction('Properties', 'readonly');
        const store = txn.objectStore('Properties');

        let query = store.get(zipcode);

        query.onsuccess = (event) => {
            if (!event.target.result) {
                console.log(`The zip with ${zipcode} not found`);
                resolve(event.target.result);
            } else {
                //console.table(event.target.result);
                resolve(event.target.result);
            }
        };

        query.onerror = (event) => {
            console.log(event.target.errorCode);
            reject(event.target.errorCode);
        }

        txn.oncomplete = function () {
            //db.close();
        };
    });
}

function getAllProperties() {
    return new Promise((resolve, reject) => {
        const txn = db.transaction('Properties', "readonly");
        const objectStore = txn.objectStore('Properties');
        let allProperties = [];

        objectStore.openCursor().onsuccess = (event) => {
            let cursor = event.target.result;
            if (cursor) {
                let value = cursor.value;
                // console.log(value);
                allProperties.push({
                    key: cursor.key,
                    value: cursor.value
                });
                // continue next record
                cursor.continue();
            } else {
                // No more properties
                resolve(allProperties);
            }
        };
        // close the database connection
        txn.oncomplete = function () {
            //db.close();
        };
    });
}

function deleteZipcode( zip) {

    return new Promise((resolve, reject) => {
        // create a new transaction
        const txn = db.transaction('Properties', 'readwrite');

        // get the Contacts object store
        const store = txn.objectStore('Properties');
        //
        let query = store.delete(zip);

        // handle the success case
        query.onsuccess = function (event) {
            console.log(event);
            resolve(event);
        };

        // handle the error case
        query.onerror = function (event) {
            resolve(event.target.errorCode);
        }

        // close the database once the 
        // transaction completes
        txn.oncomplete = function () {
            // db.close();
        };
    });
}

function closeDb() {
    return new Promise((resolve) => {
        db.close();
        resolve();
    });
}