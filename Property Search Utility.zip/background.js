import {EventDispatcher} from './scripts/EventDispatcher.js';
import { myHouseDealsMessageHandler } from "./background-scripts/myhousedeals.js";
import { investorliftMessageHandler } from "./background-scripts/investorlift.js";
import { CreateTabAsync, NavigateAsync, delay, sleepUntil } from "./helpers.js";

class ResponseEvent extends EventDispatcher {
	start(response) {
		this.dispatchEvent( {type: 'start', message: response} );
	}
}

// Using events
const responseEvent = new ResponseEvent();
console.log("In background", responseEvent);
let cancel;

// responseEvent.addEventListener('start', function ( event ) {
//     // console.log("Received response via event", event);
// });
// responseEvent.start({test: "Testing testing"});

const household_tools = [
    "Hammer",
    "Screwdriver",
    "Wrench",
    "Pliers",
    "Tape Measure",
    "Utility Knife",
    "Level",
    "Adjustable Spanner",
    "Allen Wrench",
    "Handsaw",
    "Drill",
    "Caulking Gun",
    "Stud Finder",
    "Flashlight",
    "Sanding Block",
    "Wire Cutters",
    "Hacksaw",
    "Pipe Wrench",
    "Chisel",
    "Claw Hammer",
    "Vise Grip",
    "Putty Knife",
    "Staple Gun",
    "Paintbrush",
    "Paint Roller",
    "Ladder",
    "Crowbar",
    "Carpenter's Square",
    "Angle Grinder",
    "Circular Saw"
]


async function GetLowesProducts(tab) {
    return new Promise((resolve, reject) => {
        const msg = {from: 'background', subject: 'GetProds'}
        chrome.tabs.sendMessage(tab.id, msg, (r) => {
            console.log(`message from background: ${JSON.stringify(r)}`);
            resolve(r);
        });
    });
}


const messageHandler = (msg, sender, response) => {

    const household_tool = household_tools[(Math.floor(Math.random() * household_tools.length))];
    const query = encodeURIComponent(household_tool);
    const url = `https://www.lowes.com/search?searchTerm=${query}&selectedDeliveryZipCode=33033`;
    const offsetUrl = `https://www.lowes.com/search?searchTerm=${query}&offset=${24}`
    let lowesTab;
    const lowesProducts = [];
    

    // First, validate the message's structure.
    if ((msg.from === 'popup') && (msg.subject === 'lowes')) {
        // Collect the necessary data. 
        console.log("Message received");

        (async () => {
            lowesTab = await CreateTabAsync({url, active: false});

            await NavigateAsync(lowesTab, {url, active: false});
            let prods = await GetLowesProducts(lowesTab);
            lowesProducts.push(...prods?.itemList);

            await delay(1200);

            // await NavigateAsync(lowesTab, {url: offsetUrl, active: false});
            // prods = await GetLowesProducts(lowesTab);
            // lowesProducts.push(...prods?.itemList);

            response(lowesProducts);
        })();

        return true;
    }

    if ((msg.from === 'popup') && (msg.subject === 'homedepot')) {

        // Collect the necessary data. 
        console.log("Message received: Home depot");
        let hdUrl = "https://www.homedepot.com/s/light%20fixture?NCNI-5";

        const products = [];
        let responseStore = [];

        (async () => {
            await chrome.scripting.registerContentScripts([
                {
                    id: "monkey-patch-script",
                    matches: ["https://www.lowes.com/*", "https://*.homedepot.com/*"],
                    js: ["scripts/response-helper.js"],
                    runAt: "document_start",
                    world: "MAIN"
                }
            ]);

            const reHandler = async (event) => {
                // console.log("Received response via event", event.message);
                
                if(event.message?.url.includes("opname=searchModel")) {
                    responseStore.push(event.message);
                    const data = event.message.data.data
                    products.push(...data.searchModel.products);

                    /*responseEvent.removeEventListener("start", reHandler);

                    // Unregister script
                    const scripts = await chrome.scripting.getRegisteredContentScripts();
                    const scriptIds = scripts.map(script => script.id);
                    
                    await chrome.scripting.unregisterContentScripts({ids: scriptIds}); //["monkey-patch-script"]
                    console.log("Unsubscribed");
                    console.log("Received response via event", event.message);
                    response(event.message);*/
                }
            }
            responseEvent.addEventListener('start', reHandler);


            const hdTab = await CreateTabAsync({active: false});

            await NavigateAsync(hdTab, {url: hdUrl, active: false});

            await sleepUntil(() => responseStore.length > 0, 5000);
            responseStore = [];

            hdUrl = "https://www.homedepot.com/s/light%20fixture?NCNI-5&Nao=48";
            await NavigateAsync(hdTab, {url: hdUrl, active: false});

            await sleepUntil(() => responseStore.length > 0, 5000);
            responseStore = [];

            
            responseEvent.removeEventListener("start", reHandler);

            // Unregister script
            const scripts = await chrome.scripting.getRegisteredContentScripts();
            const scriptIds = scripts.map(script => script.id);
            
            await chrome.scripting.unregisterContentScripts({ids: scriptIds}); //["monkey-patch-script"]
            console.log("Unsubscribed");
            response(products);
            chrome.tabs.remove(hdTab.id, function() { });
        })();

        return true;
    }

    if ((msg.from === 'homedepot') && (msg.subject === 'homedepot-response')) {
        // console.log(msg.payload);
        responseEvent.start(msg.payload);
        // return true;
    }


    if ((msg.from === 'popup') && (msg.subject === 'investorlift')) {
        let result = investorliftMessageHandler(msg, sender, response);
        cancel = result.cancel;
        return true;
    }

    if ((msg.from === 'popup') && (msg.subject === 'myhousedeals')) {
        let result = myHouseDealsMessageHandler(msg, sender, response);
        cancel = result.cancel;
        return true;
    }

    if ((msg.from === 'popup') && (msg.subject === 'cancel')) {
        if(!cancel)
            return false;
        
        cancel();
        response({canceled: true});
        return true;
    }

    if ((msg.from === 'popup') && (msg.subject === 'isInstalled')) {
        response({isInstalled: true});
        return true;
    }

}

// Listen for messages from the popup.
chrome.runtime.onMessage.addListener(messageHandler);

chrome.runtime.onMessageExternal.addListener(messageHandler);


//   <section uk-grid class="uk-grid-small" id="search-box-content-section">
//     <input type="hidden" id="ddlSearchAvailability" name="SearchAvailability" value="yes"/>
//     <input type="hidden" name="SearchPropertyType" value=""/>
//     <input type="hidden" id="ddlSearchLocationFilter" name="SearchLocationFilter" value="marketarea"/>
//     <input type="hidden" id="SearchMarketAreaSelect" name="SearchMarketArea" value="St Louis"/>
//     <input type="hidden" name="SearchZipCode" value=""/>
//     <input type="hidden" id="ddlSearchDistance" name="SearchDistance" value="15"/>
//     <input type="hidden" name="SearchStreetAddress" value="All Addresses"/>
//     <input type="hidden" name="SearchCity" value=""/>
//     <input type="hidden" id="ddlSearchState" name="SearchState" value=""/>
//     <input type="hidden" id="ddlSearchStateAll" name="SearchStateAll" value="1"/>
//     <input type="hidden" id="ddlSearchCounty" name="SearchCounty" value="BALDWIN"/>
//     <input type="hidden" id="ddlSearchARVStart" name="SearchARVStart" value=""/>
//     <input type="hidden" id="ddlSearchARVEnd" name="SearchARVEnd" value=""/>
//     <input type="hidden" id="ddlSearchAskingStart" name="SearchAskingStart" value=""/>
//     <input type="hidden" id="ddlSearchAskingEnd" name="SearchAskingEnd" value=""/>
//     <input type="hidden" id="ddlSearchRepairsStart" name="SearchRepairsStart" value=""/>
//     <input type="hidden" id="ddlSearchRepairsEnd" name="SearchRepairsEnd" value=""/>
//     <input type="hidden" id="ddlSearchEquityStart" name="SearchEquityStart" value=""/>
//     <input type="hidden" id="ddlSearchEquityEnd" name="SearchEquityEnd" value=""/>
//     <input type="hidden" id="ddlSearchPercentEquity" name="SearchPercentEquity" value=""/>
//     <input type="hidden" id="ddlSearchBedsStart" name="SearchBedsStart" value="2"/>
//     <input type="hidden" id="ddlSearchBedsEnd" name="SearchBedsEnd" value="3"/>
//     <input type="hidden" id="ddlSearchBathsStart" name="SearchBathsStart" value=""/>
//     <input type="hidden" id="ddlSearchBathsEnd" name="SearchBathsEnd" value=""/>
//     <input type="hidden" id="ddlSearchGaragesStart" name="SearchGaragesStart" value=""/>
//     <input type="hidden" id="ddlSearchGaragesEnd" name="SearchGaragesEnd" value=""/>
//     <input type="hidden" name="SearchSellersName" value="All Sellers"/>
//     <input type="hidden" id="SearchPropertyTags" name="SearchPropertyTags" value=""/>
// </section>


/*const params = {
                    "SearchLocationString":"St Louis Market Area",
                    "SearchLeadType1": "Yes",
                    "SearchLeadType2": "Yes",
                    "SearchLeadType3": "Yes",
                    "SearchLeadType4": "Yes",
                    "SearchLeadType5": "Yes",
                    "SearchLeadType99": "Yes",
                    "SearchAvailability":"yes",
                    "SearchPropertyType":"",
                    "SearchLocationFilter":"location",
                    "SearchMarketArea":"St Louis",
                    "SearchZipCode":"",
                    "SearchDistance":"15",
                    "SearchStreetAddress":"",
                    "SearchCity":"",
                    "SearchState":"",
                    "SearchStateAll":"1",
                    "SearchCounty":"BALDWIN",
                    "SearchARVStart":"",
                    "SearchARVEnd":"",
                    "SearchAskingStart":"",
                    "SearchAskingEnd":"",
                    "SearchRepairsStart":"",
                    "SearchRepairsEnd":"",
                    "SearchEquityStart":"",
                    "SearchEquityEnd":"",
                    "SearchPercentEquity":"",
                    "SearchBedsStart":"2",
                    "SearchBedsEnd":"3",
                    "SearchBathsStart":"",
                    "SearchBathsEnd":"",
                    "SearchGaragesStart":"",
                    "SearchGaragesEnd":"",
                    "SearchSellersName":"",
                    "SearchPropertyTags":"",
                    "SearchFavorites":"",
                    "SearchNotes":"",
                    "SearchComments":"",
                    "SearchPopular":"",
                    "SearchSaved":"",
                    "SearchSortOrder":"date_posted",
                    "SubmitSearch":"Search Properties",
                    "sortBy":"date_posted"
                  }*/