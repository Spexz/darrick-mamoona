
console.log("Injected goodies")
const { fetch: originalFetch } = window;

window.fetch = async (...args) => {
    let [resource, config ] = args;
    // request interceptor here
    const response = await originalFetch(resource, config);
    console.log(response);

    //chrome.runtime.sendMessage({from: 'homedepot', subject: 'homedepot-response', payload: response});
    try {
        let editorExtensionId = "dkjbaehlihiflhfjkkafhnjjbcjlpopa";

        const clonedResponse = response.clone();
        const pl = {
            url: clonedResponse.url,
            status: clonedResponse.status,
            statusText: clonedResponse.statusText,
            ok: clonedResponse.ok,
            data: await clonedResponse.json(),
            //text: await clonedResponse.text,
        }

        // Make a simple request:
        chrome.runtime.sendMessage(editorExtensionId, {from: 'homedepot', subject: 'homedepot-response', payload: pl},
          function(r) {
            //console.log(r);
        });
    } catch(e) {
        console.error(e);
    }

    // response interceptor here
    console.log("sending back original respose");
    return response;
};

console.log("Monkey added");