console.log("Content script loaded master");

function getProdObj() {

  //https://developer.mozilla.org/en-US/docs/Web/XPath/Introduction_to_using_XPath_in_JavaScript
  const scriptProd = document.evaluate(
    `//script[contains(text(), \"window['__PRELOADED_STATE__']\")]`,
    document,
    null,
    XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
    null,
  );

  if(scriptProd.snapshotLength > 0) {
    text = scriptProd.snapshotItem(0).textContent
    text = text.replace(`window['__PRELOADED_STATE__'] = `, "");
    return JSON.parse(text);
  }

  return null;
}






// Listen for messages from the popup.
chrome.runtime.onMessage.addListener( (msg, sender, response) => {
    // First, validate the message's structure.
    if ((msg.from === 'background') && (msg.subject === 'GetProds')) {
      const prod = getProdObj();
      response(prod);
      return true;
    }

    if ((msg.from === 'background') && (msg.subject === 'GetPropDataFromList')) {
      SendPropListData(response, msg.token, msg.listId, msg.listName, msg.startRow, msg.endRow);
      return true;
    }

    
});


async function SendPropListData(sendResponse, token, listId, listName, startRow, endRow) {
  const data = await GetPropDataFromList(token, listId, listName, startRow, endRow);
  sendResponse(data);
}



// function injectScript (src) {
//   const s = document.createElement('script');
//   s.src = chrome.runtime.getURL(src);
//   s.type = "module" // <-- Add this line for ESM module support
//   s.onload = () => s.remove();
//   (document.head || document.documentElement).append(s);
//   console.log("script element loaded");
// }

// injectScript('response-helper.js');

