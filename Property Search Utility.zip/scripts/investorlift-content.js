

async function getProperties() {
    return new Promise((resolve, reject) => {
        try {
            fetch("https://investorlift.com/api/properties/select", {
            "headers": {
                "accept": "application/json, text/plain, */*",
                "accept-language": "en-US,en;q=0.9",
                "content-type": "application/json",
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": "\"Windows\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-origin"
            },
            "referrer": "https://investorlift.com/",
            "referrerPolicy": "strict-origin-when-cross-origin",
            "body": "{\"status\":\"\"}",
            "method": "POST",
            "mode": "cors",
            "credentials": "include"
            }).then(async result => {
                const data = await result.json();
                // data["all_states"] = __NUXT__.config.all_states;
                // data["property_types"] = __NUXT__.config.property_types;
                // data["property_tags"] = __NUXT__.config.property_tags;

                // console.log(data);
                resolve(data);
            });
        } catch(e) {
            resolve({error: e.message});
        }
    });
}