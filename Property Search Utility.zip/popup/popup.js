// Initialize background page
// chrome.runtime.getBackgroundPage(function(backgroundPage) {
//     console = backgroundPage.console;
//   })


/* let button = document.getElementById("test-scraper");

button.addEventListener(
    "click", () => {
    
        // chrome.tabs.create({url: chrome.extension.getURL('../background.html')});
        // chrome.tabs.create({ url: "../background.html" });

        // chrome.runtime.sendMessage({from: 'popup', subject: 'homedepot'}, (response) => {
        //     console.log("HomeDepot Popup JS", response);
        // });

        // alert("message sent")

        // chrome.runtime.sendMessage({from: 'popup', subject: 'lowes'}, (response) => {
        //     console.log("Lowes - Popup JS", response);
        // });

        chrome.runtime.sendMessage({from: 'popup', subject: 'investorlift'}, (response) => {
            console.log("Investorlift - Popup JS", response);
        });

        

    }, false);

let button2 = document.getElementById("test-scraper-mhd");
button2.addEventListener(
    "click", () => {
        const address = {
            "zip": "36104",
            "county": "Montgomery County",
            "formatted_address": "251 S Lawrence St, Montgomery, AL 36104, USA",
            "location": {
                "lng": -86.3055826,
                "lat": 32.3744975
            },
            "state": "AL"
        };

        const params = {
            "address": "251 S. Lawrence Street, Montgomery, Alabama, 36104",
            "source": "investorlift.com",
            "minPrice": "30000",
            "maxPrice": "",
            "minARV": "",
            "maxARV": ""
        }

        chrome.runtime.sendMessage({from: 'popup', subject: 'myhousedeals', address, params}, (response) => {
            console.log("MyHouseDeals - Popup JS", response);
        });
    }, false); */