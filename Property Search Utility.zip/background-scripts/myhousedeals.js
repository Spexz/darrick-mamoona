import { CreateTabAsync, NavigateAsync } from "../helpers.js";


function myHouseDealsMessageHandler(msg, sender, response) {
    // Collect the necessary data. 
    console.log("Message received for myhousedeals");
    const addressObj = msg?.address;
    const filters = msg?.params;
    const prevResult = msg?.prevResult;
    let mhdTab;

    console.log(msg);

    let cancel = () => {
        chrome.tabs.remove(mhdTab.id, ()=> {});
        response({canceled: true});
    }

    // 
    (async () => {
        
        
        const address = addressObj.formatted_address//"6040 n pointe blvd, saint louis, mo 63147";
        const mhdUrl = "https://www.myhousedeals.com/home.asp"; 
        mhdTab = await CreateTabAsync({active: false});

        try {
            await NavigateAsync(mhdTab, {url: mhdUrl, active: false});

            // custom search filters
            let params;
            let result;
            let injectionResults;

            if(!prevResult) {
                params = {
                    "SearchARVStart": filters.minARV,
                    "SearchARVEnd": filters.maxARV,
                    "SearchAskingStart": filters.minPrice,
                    "SearchAskingEnd": filters.maxPrice,
                }
                injectionResults = await runScript(mhdTab, getPropertiesFromMHDFirstLoad, [address, params]);
                result = injectionResults;
                console.log(result);
            } else {
                // If continuing
                injectionResults = await runScript(mhdTab, getPropertiesFromMHDFirstLoad, [address, prevResult.params]);
                result = prevResult;
            }

            const MAX_REQUEST = 10;

            for(let requestCount = 0; requestCount < MAX_REQUEST; requestCount++) {
                injectionResults = await runScript(mhdTab, getPropertiesFromMHD, [result.next, result.url]);
                let props = injectionResults;
                console.log(props);
                
                //result.properties.push(...props.properties);
                result = {
                    ...result,
                    ...props,
                    properties: [...result.properties, ...props.properties]
                }

                if(!props.next || result.properties.length > 20)
                    break;
            }

            // Get page details
            for(let i in result.properties) {
                let p = result.properties[i];
                
                let propertyDetails = await runScript(mhdTab, getPropertyDetailsFromMHD, [p.id, p.url]);
                result.properties[i] = {...p, ...propertyDetails};
                
            }

            response(result);
        } catch(e) {
            console.log(e);
            response({
                error: e.message
            });
        }

        chrome.tabs.remove(mhdTab.id, ()=> {});
    })();

    return {
        cancel
    };
}

async function getPropertiesFromMHDFirstLoad(address, selectedParams = {}) {
    return new Promise(async (resolve, reject) => {
        try {
            let result = await getPropertiesFirstLoad(address, selectedParams);
            resolve(result);
        } catch(e) {
            console.log(e.message);
            reject(e);
        }
    });
}

async function getPropertiesFromMHD(offset, referrer) {
    return new Promise(async (resolve, reject) => {
        try {
            let result = await getProperties(offset, referrer);
            resolve(result);
        } catch(e) {
            console.log(e.message);
            reject(e);
        }
    });
}

async function getPropertyDetailsFromMHD(id, referrer) {
    return new Promise(async (resolve, reject) => {
        try {
            let result = await getPropertyDetails(id, referrer);
            resolve(result);
        } catch(e) {
            console.log(e.message);
            reject(e);
        }
    });
}

async function runScript(tab, f, a) {
    return new Promise((resolve, reject) => {
        chrome.scripting
            .executeScript({
            target : {tabId : tab.id},
            func : f,
            args: a
        })
        .then(async (injectionResults) => {
            let result = injectionResults[0]?.result;

            if (chrome.runtime.lastError) {
                let errorMsg = chrome.runtime.lastError.message
                console.log("In runScript", errorMsg);
            }

            if(result === null) {
                reject(new Error("Error occurred while running content script"));
            }

            if(result?.error) {
                reject(new Error(result.error));
            }

            resolve(result);
        }).catch(e => {
            reject(e);
        });
    });
}

export { myHouseDealsMessageHandler };