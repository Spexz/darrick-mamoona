import { CreateTabAsync, NavigateAsync, runScript } from "../helpers.js";

function investorliftMessageHandler(msg, sender, response) {
    // Collect the necessary data. 
    console.log("Message received for investorlift");
    // const addressObj = msg?.payload?.address;
    // const params = msg?.payload?.params;
    let ilTab;

    async function getPropertiesIL() {
        return new Promise(async (resolve, reject) => {
            let result = await getProperties();
            resolve(result);
        });
    }

    let cancel = () => {
        chrome.tabs.remove(ilTab.id, ()=> {});
        response({canceled: true});
    }

    // t.status = ["available", "pending", "sold"][t.status_index - 2],
    (async () => {
        const ilUrl = "https://investorlift.com/";
        ilTab = await CreateTabAsync({active: false});

        try {
            await NavigateAsync(ilTab, {url: ilUrl, active: false});

            // chrome.scripting
            //     .executeScript({
            //     target : {tabId : ilTab.id},
            //     func : getPropertiesIL,
            // })
            // .then(injectionResults => {
            //     console.log(injectionResults);
            //     response(injectionResults[0]?.result);

            //     chrome.tabs.remove(ilTab.id, ()=> {});
            // });
            let injectionResults = await runScript(ilTab, getPropertiesIL, []);
            console.log(injectionResults);
            response(injectionResults);

        } catch(e) {
            console.log(e);
            response({
                error: e.message
            });
        } finally {
            chrome.tabs.remove(ilTab.id, ()=> {});
        }

    })();

    return {
        cancel
    };
}

export { investorliftMessageHandler };