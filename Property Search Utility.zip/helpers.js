function CreateTabAsync(props) {
    return new Promise((resolve, reject) => {
        chrome.tabs.create(props, tab => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError));
            } else {
                resolve(tab);
            }
        });
    });
}

function NavigateAsync(tab, props) {
    return new Promise((resolve, reject) => {
        chrome.tabs.onUpdated.addListener(function listener (tabId, info) {
            // console.log(info);

            if (info.status === 'complete' && tabId === tab.id) {
                chrome.tabs.onUpdated.removeListener(listener);
                console.log("Lowes page loaded");
                resolve(info);
            }
        });
        chrome.tabs.update(tab.id, props);
    });
}

function delay(time) {
    return new Promise(resolve => setTimeout(resolve, time));
}

//https://levelup.gitconnected.com/javascript-wait-until-something-happens-or-timeout-82636839ea93
const sleepUntil = async (f, timeoutMs) => {
    return new Promise((resolve, reject) => {
      const timeWas = new Date();
      const wait = setInterval(function() {
        if (f()) {
          console.log("resolved after", new Date() - timeWas, "ms");
          clearInterval(wait);
          resolve();
        } else if (new Date() - timeWas > timeoutMs) { // Timeout
          console.log("rejected after", new Date() - timeWas, "ms");
          clearInterval(wait);
          reject();
        }
      }, 20);
    });
}

async function runScript(tab, f, a) {
    return new Promise((resolve, reject) => {
        chrome.scripting
            .executeScript({
            target : {tabId : tab.id},
            func : f,
            args: a
        })
        .then(async (injectionResults) => {
            let result = injectionResults[0]?.result;

            if (chrome.runtime.lastError) {
                let errorMsg = chrome.runtime.lastError.message
                console.log("In runScript", errorMsg);
            }

            if(result === null) {
                reject(new Error("Error occurred while running content script"));
            }

            if(result?.error) {
                reject(new Error(result.error));
            }

            resolve(result);
        }).catch(e => {
            reject(e);
        });
    });
}

export { CreateTabAsync, NavigateAsync, delay, sleepUntil, runScript };