async function uploadPropertiesToGoogleSheet(zip) {
    const headers = VALUE_COLUMNS.reduce((a, currentValue) => 
    [...a, currentValue.headerName], []);

    const colIds = VALUE_COLUMNS.reduce((a, currentValue) => 
    [...a, currentValue.colId], []);

    console.log(headers);

    let startCol = "A";
    let endCol = colName(headers.length - 1);

    await clearSheet(`A1:${endCol}`);

    // await SendToGoogleSheet("Sheet1!A1", [headers]);
    await SendToGoogleSheet(`'${gsheetName}'!A1`, [headers]);


    await openDb();
    //Process Properties data
    let store = await getPropertiesByZipcode(zip);
    let properties = store.properties;

    let propertiesSht = [];

    for(property of properties) {
        let row = [];

        //Loop column IDs and add value to row
        for(const colId of colIds){
            //Check if column id exist in the property object and add to row array
            if(property.hasOwnProperty(colId)) {
                let val = property[colId];

                if(COLUMN_FORMATS.hasOwnProperty(colId)) {
                    if(COLUMN_FORMATS[colId] === "date") {
                        val = UnixTimeToDate(val);
                    }
                }

                row.push(val);
            } else {
                row.push("");
            }
        }

        propertiesSht.push(row);
    }
    await closeDb();
    console.log(propertiesSht);

    let batchRange = `'${gsheetName}'!A2:${endCol}${properties.length + 1}`;
    console.log(batchRange);

    await SendToGoogleSheetBatch(batchRange, propertiesSht);
}



async function SendToGoogleSheet(range, data) {
    // const sheetId = '19pkKWYij68lf6XMVL4JUiN9yUjkZGyumAOmrDHUcjvg';

    return new Promise(async (resolve, reject) => {
        // const url = `https://sheets.googleapis.com/v4/spreadsheets/${gsheetId}/values/Sheet1!A1?valueInputOption=USER_ENTERED`;
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${gsheetId}/values/${range}?valueInputOption=USER_ENTERED`;

        var params = {
            "range": range, //"Sheet1!A1",
            "majorDimension": "ROWS",
            "values": data,
        }

        const response = await fetch(url, {
            method: 'PUT',
                async: true,
                body: JSON.stringify(params),
                headers: {
                    Authorization: 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                contentType: 'json',
        });

        if (response.ok) {
            console.log('Data added successfully');
            resolve('Data added successfully');
        } else {
            console.error('Failed to add data to Google Sheet');
            reject('Failed to add data to Google Sheet');
        }
    });
}

async function SendToGoogleSheetBatch(range, data) {
    // const sheetId = '19pkKWYij68lf6XMVL4JUiN9yUjkZGyumAOmrDHUcjvg';
    console.log(data);

    return new Promise(async (resolve, reject) => {
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${gsheetId}/values:batchUpdate`;

        var params = {
            "data": [
                {
                    "range": range, //"Sheet1!A1",
                    "majorDimension": "ROWS",
                    "values": data
                }
            ],
            "valueInputOption": "USER_ENTERED",
            "includeValuesInResponse": false
        }

        const response = await fetch(url, {
            method: 'POST',
                async: true,
                body: JSON.stringify(params),
                headers: {
                    Authorization: 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                contentType: 'json',
        });

        if (response.ok) {
            console.log('Data added successfully');
            resolve('Data added successfully');
        } else {
            console.error('Failed to add data to Google Sheet');
            reject('Failed to add data to Google Sheet');
        }
    });
}

async function clearSheet(range) {
    return new Promise(async (resolve, reject) => {

        // const sheetId = '19pkKWYij68lf6XMVL4JUiN9yUjkZGyumAOmrDHUcjvg';

        const url = `https://sheets.googleapis.com/v4/spreadsheets/${gsheetId}/values/${range}:clear`;

        const response = await fetch(url, {
            method: 'POST',
                async: true,
                headers: {
                    Authorization: 'Bearer ' + token,
                    'Content-Type': 'application/json'
                },
                contentType: 'json',
        });

        if (response.ok) {
            resolve('Data added successfully');
        } else {
            reject('Failed to add data to Google Sheet');
        }
    });
    
}


function colName(n) {
    var ordA = 'A'.charCodeAt(0);
    var ordZ = 'Z'.charCodeAt(0);
    var len = ordZ - ordA + 1;
  
    var s = "";
    while(n >= 0) {
        s = String.fromCharCode(n % len + ordA) + s;
        n = Math.floor(n / len) - 1;
    }
    return s;
}

function UnixTimeToDate(unixTimestamp) {
    unixTimestamp = parseInt(unixTimestamp);
    let date = new Date(unixTimestamp);
    // Generate date string
    return date.toLocaleDateString("en-US");
}

const VALUE_COLUMNS = [
    {
      "colId":"streetAddress",
      "headerName":"Address"
    },
    {
      "colId":"unitNumber",
      "headerName":"Unit #"
    },
    {
      "colId":"cityName",
      "headerName":"City"
    },
    {
      "colId":"stateCode",
      "headerName":"State"
    },
    {
      "colId":"zip",
      "headerName":"Zip"
    },
    {
      "colId":"countyName",
      "headerName":"County"
    },
    {
      "colId":"apn",
      "headerName":"APN"
    },
    {
      "colId":"ownerOccupied",
      "headerName":"Owner Occupied"
    },
    {
      "colId":"owner1FirstName",
      "headerName":"Owner 1 First Name"
    },
    {
      "colId":"owner1LastName",
      "headerName":"Owner 1 Last Name"
    },
    {
      "colId":"owner2FirstName",
      "headerName":"Owner 2 First Name"
    },
    {
      "colId":"owner2LastName",
      "headerName":"Owner 2 Last Name"
    },
    {
      "colId":"mailCareOf",
      "headerName":"Mailing Care of Name"
    },
    {
      "colId":"mailStreetAddress",
      "headerName":"Mailing Address"
    },
    {
      "colId":"mailUnitNumber",
      "headerName":"Mailing Unit #"
    },
    {
      "colId":"mailCityName",
      "headerName":"Mailing City"
    },
    {
      "colId":"mailStateCode",
      "headerName":"Mailing State"
    },
    {
      "colId":"mailZip",
      "headerName":"Mailing Zip"
    },
    {
      "colId":"mailCountyName",
      "headerName":"Mailing County"
    },
    {
      "colId":"mailOptOut",
      "headerName":"Do Not Mail"
    },
    {
      "colId":"landUse",
      "headerName":"Property Type"
    },
    {
      "colId":"bedrooms",
      "headerName":"Bedrooms"
    },
    {
      "colId":"bathrooms",
      "headerName":"Total Bathrooms"
    },
    {
      "colId":"squareFeet",
      "headerName":"Building Sqft"
    },
    {
      "colId":"lotSquareFeet",
      "headerName":"Lot Size Sqft"
    },
    {
      "colId":"effectiveYearBuilt",
      "headerName":"Effective Year Built"
    },
    {
      "colId":"assessedValue",
      "headerName":"Total Assessed Value"
    },
    {
      "colId":"lastRecordingDate",
      "headerName":"Last Sale Recording Date"
    },
    {
      "colId":"lastSaleAmount",
      "headerName":"Last Sale Amount"
    },
    {
      "colId":"mortgage1RecordingDate",
      "headerName":"Loan 1 Date"
    },
    {
      "colId":"mortgage1Balance",
      "headerName":"Loan 1 Balance"
    },
    {
      "colId":"mortgage1LoanType",
      "headerName":"Loan 1 Type"
    },
    {
      "colId":"mortgage1LenderName",
      "headerName":"Loan 1 Lender"
    },
    {
      "colId":"mortgage1InterestRate",
      "headerName":"Loan 1 Rate"
    },
    {
      "colId":"mortgage1FinancingType",
      "headerName":"Loan 1 Rate Type"
    },
    {
      "colId":"mortgage2RecordingDate",
      "headerName":"Loan 2 Date"
    },
    {
      "colId":"mortgage2Balance",
      "headerName":"Loan 2 Balance"
    },
    {
      "colId":"mortgage2LoanType",
      "headerName":"Loan 2 Type"
    },
    {
      "colId":"mortgage2LenderName",
      "headerName":"Loan 2 Lender"
    },
    {
      "colId":"mortgage2InterestRate",
      "headerName":"Loan 2 Rate"
    },
    {
      "colId":"mortgage2FinancingType",
      "headerName":"Loan 2 Rate Type"
    },
    {
      "colId":"mortgage3RecordingDate",
      "headerName":"Loan 3 Date"
    },
    {
      "colId":"mortgage3Balance",
      "headerName":"Loan 3 Balance"
    },
    {
      "colId":"mortgage3LoanType",
      "headerName":"Loan 3 Type"
    },
    {
      "colId":"mortgage3LenderName",
      "headerName":"Loan 3 Lender"
    },
    {
      "colId":"mortgage3InterestRate",
      "headerName":"Loan 3 Rate"
    },
    {
      "colId":"mortgage3FinancingType",
      "headerName":"Loan 3 Rate Type"
    },
    {
      "colId":"mortgage4RecordingDate",
      "headerName":"Loan 4 Date"
    },
    {
      "colId":"mortgage4Balance",
      "headerName":"Loan 4 Balance"
    },
    {
      "colId":"mortgage4LoanType",
      "headerName":"Loan 4 Type"
    },
    {
      "colId":"mortgage4LenderName",
      "headerName":"Loan 4 Lender"
    },
    {
      "colId":"mortgage4InterestRate",
      "headerName":"Loan 4 Rate"
    },
    {
      "colId":"mortgage4FinancingType",
      "headerName":"Loan 4 Rate Type"
    },
    {
      "colId":"openMortgageQuantity",
      "headerName":"Total Open Loans"
    },
    {
      "colId":"openMortgageBalance",
      "headerName":"Est. Remaining balance of Open Loans"
    },
    {
      "colId":"estimatedValue",
      "headerName":"Est. Value"
    },
    {
      "colId":"ltvRatio",
      "headerName":"Est. Loan-to-Value"
    },
    {
      "colId":"estimatedEquity",
      "headerName":"Est. Equity"
    },
    {
      "colId":"mlsStatus",
      "headerName":"MLS Status"
    },
    {
      "colId":"mlsListingDate",
      "headerName":"MLS Date"
    },
    {
      "colId":"mlsListingAmount",
      "headerName":"MLS Amount"
    },
    {
      "colId":"lienDocumentType",
      "headerName":"Lien Type"
    },
    {
      "colId":"lienRecordingDate",
      "headerName":"Lien Date"
    },
    {
      "colId":"lienListingAmount",
      "headerName":"Lien Amount"
    },
    {
      "colId":"bankruptcyRecordingDate",
      "headerName":"BK Date"
    },
    {
      "colId":"divorceRecordingDate",
      "headerName":"Divorce Date"
    },
    {
      "colId":"listQuantity",
      "headerName":"Marketing Lists"
    },
    {
      "colId":"addDate",
      "headerName":"Date Added to List"
    },
    {
      "colId":"addMethod",
      "headerName":"Method of Add"
    }
  ];


  const COLUMN_FORMATS = {
    "lastRecordingDate": "date",
    "mortgage1RecordingDate": "date",
    "mortgage2RecordingDate": "date",
    "mortgage3RecordingDate": "date",
    "mortgage4RecordingDate": "date",
    "mlsListingDate": "date",
    "bankruptcyRecordingDate": "date",
    "divorceRecordingDate": "date",
    "addDate": "date",
    "lienRecordingDate": "date",
  }